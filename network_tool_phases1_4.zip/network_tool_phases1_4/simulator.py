# simulator.py
# Phase 3: Day-1 network simulation (simplified)

import time
import json
import os
from collections import defaultdict, deque


class Node:
    def __init__(self, device):
        self.id = device.id
        self.hostname = device.hostname
        self.type = device.type
        self.interfaces = {iface.name: iface for iface in device.interfaces}
        self.neighbors = {}       # iface_name -> neighbor_id
        self.arp_table = {}       # ip -> mac (fake)
        self.routes = {}          # net -> next_hop
        self.log = []

    def log_event(self, msg):
        timestamp = time.strftime("%H:%M:%S")
        self.log.append(f"[{timestamp}] {msg}")


def simulate_network(devices, topo, steps=5, out_dir="out"):
    """
    Simulates basic neighbor discovery, ARP, and route exchange.
    """
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    # Create Node objects
    nodes = {dev.id: Node(dev) for dev in devices}

    # Step 1: Neighbor discovery (LLDP/CDP-like)
    for u, v, data in topo.edges(data=True):
        nodes[u].neighbors[data["ifaces"][0]] = v
        nodes[v].neighbors[data["ifaces"][1]] = u
        nodes[u].log_event(f"Discovered neighbor {v} on {data['ifaces'][0]}")
        nodes[v].log_event(f"Discovered neighbor {u} on {data['ifaces'][1]}")

    # Step 2: Populate ARP tables (fake MACs)
    for dev in devices:
        node = nodes[dev.id]
        for iface in dev.interfaces:
            if iface.ip:
                fake_mac = f"00:aa:{hash(dev.id + iface.name) & 0xFFFFFF:06x}"
                node.arp_table[iface.ip] = fake_mac
        node.log_event("ARP table initialized")

    # Step 3: Simulate OSPF-like route learning
    # Initialize each node with directly connected networks
    for dev in devices:
        node = nodes[dev.id]
        for iface in dev.interfaces:
            if iface.ip and iface.mask:
                net = f"{iface.ip}/{iface.mask}"
                node.routes[net] = None  # directly connected
        node.log_event("Direct routes learned")

    # Propagate routes in BFS fashion
    for step in range(steps):
        updated = False
        for u, v, _ in topo.edges(data=True):
            nu, nv = nodes[u], nodes[v]
            # exchange routes
            for net in nu.routes:
                if net not in nv.routes:
                    nv.routes[net] = u
                    nv.log_event(f"Learned route {net} via {u}")
                    updated = True
            for net in nv.routes:
                if net not in nu.routes:
                    nu.routes[net] = v
                    nu.log_event(f"Learned route {net} via {v}")
                    updated = True
        if not updated:
            break

    # Save logs and snapshot
    snapshot = {}
    for nid, node in nodes.items():
        with open(os.path.join(out_dir, f"sim_logs_{nid}.txt"), "w") as f:
            f.write("\n".join(node.log))
        snapshot[nid] = {
            "hostname": node.hostname,
            "type": node.type,
            "neighbors": node.neighbors,
            "arp_table": node.arp_table,
            "routes": node.routes
        }

    snap_path = os.path.join(out_dir, f"sim_snapshot.json")
    with open(snap_path, "w") as f:
        json.dump(snapshot, f, indent=2)

    return snapshot, snap_path


if __name__ == "__main__":
    import sys
    from parser_mod import parse_all_configs
    from topology import build_topology
    if len(sys.argv) < 2:
        print("Usage: python simulator.py <conf_dir>")
    else:
        devs = parse_all_configs(sys.argv[1])
        topo = build_topology(devs)
        snapshot, path = simulate_network(devs, topo)
        print(f"Simulation snapshot saved to {path}")
