# validator.py
# Validate a topology and devices for common networking issues

from collections import defaultdict
from ipaddress import IPv4Network


def validate_devices_and_topology(devices, topo):
    findings = []

    # --- Duplicate IP detection (per VLAN/subnet) ---
    ip_map = defaultdict(list)
    for dev in devices:
        for iface in dev.interfaces:
            if iface.ip and iface.mask:
                net = None
                try:
                    net = IPv4Network(f"{iface.ip}/{iface.mask}", strict=False)
                except:
                    pass
                ip_map[(net, iface.vlan)].append((dev.id, iface.name, iface.ip))

    for (net, vlan), entries in ip_map.items():
        if len(entries) > 1:
            findings.append({
                "severity": "high",
                "title": "Duplicate IP Detected",
                "detail": f"Net {net} VLAN {vlan} has {len(entries)} devices sharing IPs.",
                "devices": entries,
                "suggested_fix": "Assign unique IPs per VLAN/subnet."
            })

    # --- VLAN mismatch on a link ---
    for u, v, data in topo.edges(data=True):
        vlan_a = data.get("vlan_a")
        vlan_b = data.get("vlan_b")
        if vlan_a and vlan_b and vlan_a != vlan_b:
            findings.append({
                "severity": "medium",
                "title": "VLAN Mismatch",
                "detail": f"Link {u}-{v} has VLAN {vlan_a} vs {vlan_b}.",
                "suggested_fix": "Match VLAN IDs or configure trunk properly."
            })

    # --- MTU mismatch ---
    for u, v, data in topo.edges(data=True):
        mtu_a = data.get("mtu")
        mtu_b = data.get("mtu")
        if mtu_a and mtu_b and mtu_a != mtu_b:
            findings.append({
                "severity": "medium",
                "title": "MTU Mismatch",
                "detail": f"Link {u}-{v} MTUs differ.",
                "suggested_fix": "Standardize MTUs for connected interfaces."
            })

    # --- Default gateway validation ---
    for dev in devices:
        if dev.default_gateway:
            gw_ip = dev.default_gateway
            match_found = False
            for iface in dev.interfaces:
                try:
                    net = IPv4Network(f"{iface.ip}/{iface.mask}", strict=False)
                    if gw_ip in str(net):
                        match_found = True
                        break
                except:
                    pass
            if not match_found:
                findings.append({
                    "severity": "medium",
                    "title": "Gateway Outside Subnet",
                    "detail": f"{dev.id} default gateway {gw_ip} not in any of its subnets.",
                    "suggested_fix": "Update gateway to match a connected network."
                })

    # --- Missing device detection ---
    connected_devices = set(topo.nodes())
    for dev in devices:
        if dev.id not in connected_devices:
            findings.append({
                "severity": "low",
                "title": "Isolated Device",
                "detail": f"{dev.id} not connected to any other device in topology.",
                "suggested_fix": "Check cabling or config for this device."
            })

    return findings


if __name__ == "__main__":
    from parser_mod import parse_all_configs
    from topology import build_topology
    import sys, json
    if len(sys.argv) < 2:
        print("Usage: python validator.py <conf_dir>")
    else:
        devs = parse_all_configs(sys.argv[1])
        topo = build_topology(devs)
        results = validate_devices_and_topology(devs, topo)
        print(json.dumps(results, indent=2))
