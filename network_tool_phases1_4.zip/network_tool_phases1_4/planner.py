# planner.py
# Suggests improvements for network configuration and design based on validation findings

def plan_improvements(findings):
    """
    Given a list of findings from validator, generate a plan of action.
    Each plan item will contain: title, devices affected, and action steps.
    """
    plans = []

    for f in findings:
        plan = {
            "title": f.get("title", "Untitled Issue"),
            "priority": f.get("severity", "low"),
            "devices": f.get("devices", []),
            "action": f.get("suggested_fix", "Review and adjust configuration.")
        }
        plans.append(plan)

    # Sort by priority: high > medium > low
    priority_order = {"high": 1, "medium": 2, "low": 3}
    plans.sort(key=lambda p: priority_order.get(p["priority"], 4))

    return plans


if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 2:
        print("Usage: python planner.py <findings.json>")
    else:
        with open(sys.argv[1], "r") as f:
            findings = json.load(f)
        plan = plan_improvements(findings)
        print(json.dumps(plan, indent=2))
