# main.py
# Unified CLI for Phases 1-4 network tool

import argparse
import json
import os
from parser_mod import parse_all_configs
from topology import build_topology
from validator import validate_devices_and_topology
from planner import plan_improvements
from simulator import simulate_network
from injector import inject_fault
from optimizer import optimize_network


def save_json(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
    print(f"[+] Saved {path}")


def cmd_parse(args):
    devices = parse_all_configs(args.confdir)
    data = [d.to_dict() for d in devices]
    save_json(data, "parsed_devices.json")


def cmd_topo(args):
    devices = parse_all_configs(args.confdir)
    topo = build_topology(devices)
    topo_data = {
        "nodes": list(topo.nodes()),
        "links": [
            {"a": u, "b": v, "attrs": d}
            for u, v, k, d in topo.edges(keys=True, data=True)
        ]
    }
    save_json(topo_data, "topology.json")


def cmd_validate(args):
    devices = parse_all_configs(args.confdir)
    topo = build_topology(devices)
    findings = validate_devices_and_topology(devices, topo)
    save_json(findings, "findings.json")


def cmd_plan(args):
    with open(args.findings, "r") as f:
        findings = json.load(f)
    plan = plan_improvements(findings)
    save_json(plan, "plan.json")


def cmd_simulate(args):
    devices = parse_all_configs(args.confdir)
    topo = build_topology(devices)
    snapshot, path = simulate_network(devices, topo, steps=5, out_dir=args.outdir)
    print(f"[+] Simulation snapshot at {path}")


def cmd_inject(args):
    new_snap, report, snap_path, rep_path = inject_fault(args.snapshot, args.event, args.target)
    print(f"[+] New snapshot: {snap_path}")
    print(f"[+] Report: {rep_path}")


def cmd_optimize(args):
    with open(args.findings, "r") as f:
        findings = json.load(f)
    snapshot = args.snapshot if args.snapshot else None
    opts = optimize_network(findings, snapshot)
    save_json(opts, "optimizations.json")


def main():
    parser = argparse.ArgumentParser(description="Cisco VIP 2025 Networking Tool CLI (Phases 1–4)")
    sub = parser.add_subparsers(dest="cmd")

    # Phase 1
    p_parse = sub.add_parser("parse", help="Parse configs into structured data")
    p_parse.add_argument("confdir", help="Directory with config files")
    p_parse.set_defaults(func=cmd_parse)

    p_topo = sub.add_parser("topo", help="Build network topology")
    p_topo.add_argument("confdir", help="Directory with config files")
    p_topo.set_defaults(func=cmd_topo)

    # Phase 2
    p_val = sub.add_parser("validate", help="Validate network for issues")
    p_val.add_argument("confdir", help="Directory with config files")
    p_val.set_defaults(func=cmd_validate)

    p_plan = sub.add_parser("plan", help="Generate plan from findings")
    p_plan.add_argument("findings", help="Findings JSON file from validate step")
    p_plan.set_defaults(func=cmd_plan)

    # Phase 3
    p_sim = sub.add_parser("simulate", help="Run Day-1 simulation")
    p_sim.add_argument("confdir", help="Directory with config files")
    p_sim.add_argument("--outdir", default="out", help="Output directory")
    p_sim.set_defaults(func=cmd_simulate)

    # Phase 4
    p_inj = sub.add_parser("inject", help="Inject fault into simulation snapshot")
    p_inj.add_argument("snapshot", help="Simulation snapshot JSON")
    p_inj.add_argument("--event", required=True, help="Event type (link_down, node_down, mtu_change, bad_route)")
    p_inj.add_argument("--target", required=True, help="Target of the event")
    p_inj.set_defaults(func=cmd_inject)

    # Optimization
    p_opt = sub.add_parser("optimize", help="Generate optimized config suggestions")
    p_opt.add_argument("findings", help="Findings JSON")
    p_opt.add_argument("--snapshot", help="Simulation snapshot JSON")
    p_opt.set_defaults(func=cmd_optimize)

    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
