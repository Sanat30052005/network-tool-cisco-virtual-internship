# parser_mod.py
# Robust-ish parser for Cisco-like config dumps (hostname, interfaces, IPs, MTU, speed,
# description, switchport access/trunk, default-gateway, static default route).
# Output: Device and Interface objects with to_dict() for JSON serialization.

import os
import re
from ipaddress import ip_network


class Interface:
    def __init__(self, name):
        self.name = name
        self.ip = None        # string, e.g. "10.0.0.1"
        self.mask = None      # string, e.g. "255.255.255.0"
        self.mtu = None       # int
        self.speed = None     # int (Mbps)
        self.desc = None      # description string
        self.vlan = None      # access vlan int
        self.trunk_vlans = None  # trunk allowed vlans string, e.g. "10,20-30"

    def to_dict(self):
        return {
            "name": self.name,
            "ip": self.ip,
            "mask": self.mask,
            "mtu": self.mtu,
            "speed": self.speed,
            "description": self.desc,
            "vlan": self.vlan,
            "trunk_vlans": self.trunk_vlans,
        }


class Device:
    def __init__(self, dev_id):
        self.id = dev_id
        self.hostname = dev_id
        self.type = "router"    # router | switch | endpoint
        self.interfaces = []    # list of Interface
        self.default_gateway = None

    def to_dict(self):
        return {
            "id": self.id,
            "hostname": self.hostname,
            "type": self.type,
            "default_gateway": self.default_gateway,
            "interfaces": [i.to_dict() for i in self.interfaces],
        }


# regex compiled patterns used by parser
_RE_HOSTNAME = re.compile(r'^\s*hostname\s+(\S+)', re.M | re.I)
_RE_DEF_GW = re.compile(r'^\s*ip\s+default-gateway\s+(\S+)', re.M | re.I)
_RE_ROUTE0 = re.compile(r'^\s*ip\s+route\s+0\.0\.0\.0\s+0\.0\.0\.0\s+(\S+)', re.M | re.I)
_RE_IFACE = re.compile(r'^\s*interface\s+(\S+)', re.I)
_RE_IPADDR = re.compile(r'^\s*ip\s+address\s+(\S+)\s+(\S+)', re.I)
_RE_MTU = re.compile(r'^\s*mtu\s+(\d+)', re.I)
_RE_SPEED = re.compile(r'^\s*speed\s+(\d+)', re.I)
_RE_DESC = re.compile(r'^\s*description\s+(.+)', re.I)
_RE_ACCESS_VLAN = re.compile(r'^\s*switchport\s+access\s+vlan\s+(\d+)', re.I)
_RE_TRUNK_VLANS = re.compile(r'^\s*switchport\s+trunk\s+allowed\s+vlan\s+([\d,\-]+)', re.I)


def parse_config_text(text, dev_id):
    """
    Parse a single config text and return a Device object.
    """
    dev = Device(dev_id)

    # hostname
    m = _RE_HOSTNAME.search(text)
    if m:
        dev.hostname = m.group(1).strip()
    # infer device type heuristics
    if dev.hostname.upper().startswith("HOST") or "HOST" in dev.hostname.upper():
        dev.type = "endpoint"
    elif re.search(r'\bswitch\b', text, re.I) or re.search(r'switchport', text, re.I):
        dev.type = "switch"
    else:
        dev.type = "router"

    # default gateway / static default route
    m_gw = _RE_DEF_GW.search(text)
    if m_gw:
        dev.default_gateway = m_gw.group(1).strip()
    else:
        m_r = _RE_ROUTE0.search(text)
        if m_r:
            dev.default_gateway = m_r.group(1).strip()

    # split into interface blocks
    # strategy: find "interface NAME" occurrences and capture following indented lines until next "interface" or EOF
    iface_splits = re.split(r'\n(?=\s*interface\s+)', text, flags=re.I)
    for block in iface_splits:
        m_if = _RE_IFACE.search(block)
        if not m_if:
            continue
        if_name = m_if.group(1).strip()
        intf = Interface(if_name)

        # inspect each line of the block
        for line in block.splitlines()[1:]:
            ln = line.strip()
            if not ln:
                continue
            m_ip = _RE_IPADDR.match(ln)
            if m_ip:
                intf.ip = m_ip.group(1)
                intf.mask = m_ip.group(2)
                continue
            m_mtu = _RE_MTU.match(ln)
            if m_mtu:
                try:
                    intf.mtu = int(m_mtu.group(1))
                except:
                    pass
                continue
            m_sp = _RE_SPEED.match(ln)
            if m_sp:
                try:
                    intf.speed = int(m_sp.group(1))
                except:
                    pass
                continue
            m_desc = _RE_DESC.match(ln)
            if m_desc:
                intf.desc = m_desc.group(1).strip()
                continue
            m_acc = _RE_ACCESS_VLAN.match(ln)
            if m_acc:
                try:
                    intf.vlan = int(m_acc.group(1))
                except:
                    pass
                continue
            m_tr = _RE_TRUNK_VLANS.match(ln)
            if m_tr:
                intf.trunk_vlans = m_tr.group(1).strip()
                continue

        dev.interfaces.append(intf)

    return dev


def parse_all_configs(conf_dir):
    """
    Walk conf_dir and parse files ending with .dump, .cfg, .conf
    Returns list of Device objects.
    """
    devices = []
    if not os.path.isdir(conf_dir):
        return devices

    for root, _, files in os.walk(conf_dir):
        for fn in sorted(files):
            if not fn.lower().endswith(('.dump', '.cfg', '.conf')):
                continue
            path = os.path.join(root, fn)
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    txt = f.read()
            except Exception:
                # try with latin1
                with open(path, 'r', encoding='latin1') as f:
                    txt = f.read()
            dev_id = os.path.splitext(fn)[0]
            try:
                dev = parse_config_text(txt, dev_id)
                devices.append(dev)
            except Exception:
                # be tolerant — skip problematic files but continue
                continue
    return devices


# small helper
def ip_to_net(ip, mask):
    try:
        return str(ip_network(f"{ip}/{mask}", strict=False))
    except Exception:
        return None


# Quick test when run standalone
if __name__ == "__main__":
    import sys, json
    if len(sys.argv) < 2:
        print("Usage: python parser_mod.py <conf_dir>")
    else:
        devs = parse_all_configs(sys.argv[1])
        print(json.dumps([d.to_dict() for d in devs], indent=2))
