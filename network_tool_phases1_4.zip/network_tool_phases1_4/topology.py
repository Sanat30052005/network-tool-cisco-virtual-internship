# topology.py
# Build a network topology graph from parsed devices using IP subnet matching and interface descriptions.

import networkx as nx
from ipaddress import IPv4Network


def same_subnet(ip_a, mask_a, ip_b, mask_b):
    """
    Check if two IP+mask pairs are in the same subnet.
    """
    try:
        net_a = IPv4Network(f"{ip_a}/{mask_a}", strict=False)
        net_b = IPv4Network(f"{ip_b}/{mask_b}", strict=False)
        return net_a.network_address == net_b.network_address and net_a.prefixlen == net_b.prefixlen
    except Exception:
        return False


def build_topology(devices):
    """
    Given a list of Device objects, return a MultiGraph where nodes are device IDs,
    and edges have attributes: ifaces, speed, mtu, vlan_a, vlan_b.
    """
    G = nx.MultiGraph()

    # Add all devices as nodes
    for dev in devices:
        G.add_node(dev.id, device=dev)

    # Compare all pairs of devices to detect links
    for i in range(len(devices)):
        for j in range(i + 1, len(devices)):
            dev_a = devices[i]
            dev_b = devices[j]

            # Try to match by IP subnet
            for iface_a in dev_a.interfaces:
                for iface_b in dev_b.interfaces:
                    if iface_a.ip and iface_b.ip and iface_a.mask and iface_b.mask:
                        if same_subnet(iface_a.ip, iface_a.mask, iface_b.ip, iface_b.mask):
                            G.add_edge(
                                dev_a.id,
                                dev_b.id,
                                ifaces=(iface_a.name, iface_b.name),
                                speed=min((iface_a.speed or 1000), (iface_b.speed or 1000)),
                                mtu=min((iface_a.mtu or 1500), (iface_b.mtu or 1500)),
                                vlan_a=iface_a.vlan,
                                vlan_b=iface_b.vlan
                            )

            # Try to match by description (if interface desc contains other device's ID or hostname)
            for iface_a in dev_a.interfaces:
                if iface_a.desc and (dev_b.id in iface_a.desc or dev_b.hostname in iface_a.desc):
                    # Find a suitable iface on dev_b to connect
                    iface_b = dev_b.interfaces[0] if dev_b.interfaces else None
                    G.add_edge(
                        dev_a.id,
                        dev_b.id,
                        ifaces=(iface_a.name, iface_b.name if iface_b else None),
                        speed=min((iface_a.speed or 1000), (iface_b.speed or 1000 if iface_b else 1000)),
                        mtu=min((iface_a.mtu or 1500), (iface_b.mtu or 1500 if iface_b else 1500)),
                        vlan_a=iface_a.vlan,
                        vlan_b=iface_b.vlan if iface_b else None
                    )

    return G


# Quick test
if __name__ == "__main__":
    from parser_mod import parse_all_configs
    import sys, json
    if len(sys.argv) < 2:
        print("Usage: python topology.py <conf_dir>")
    else:
        devs = parse_all_configs(sys.argv[1])
        topo = build_topology(devs)
        topo_data = {
            "nodes": [n for n in topo.nodes()],
            "links": [
                {"a": u, "b": v, "attrs": d}
                for u, v, k, d in topo.edges(keys=True, data=True)
            ]
        }
        print(json.dumps(topo_data, indent=2))
