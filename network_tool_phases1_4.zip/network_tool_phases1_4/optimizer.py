# optimizer.py
# Suggest optimized configurations based on findings and plans

import json
import os


def optimize_network(findings, snapshot_path=None):
    """
    Given validation findings (list of dicts), produce optimized config suggestions.
    Optionally uses simulation snapshot for context.
    """
    optimizations = []

    # Optional: load simulation snapshot for richer context
    snapshot = None
    if snapshot_path and os.path.exists(snapshot_path):
        with open(snapshot_path, "r") as f:
            snapshot = json.load(f)

    for f in findings:
        title = f.get("title", "Issue")
        severity = f.get("severity", "low")
        fix = f.get("suggested_fix", "")

        suggestion = {
            "issue": title,
            "priority": severity,
            "suggestion": fix
        }

        # Example: If VLAN mismatch and snapshot exists, list affected link details
        if "VLAN Mismatch" in title and snapshot:
            suggestion["context"] = "Check both ends of the affected link in snapshot for VLAN configs."

        # Example: If Gateway Outside Subnet, suggest correct gateway if possible
        if "Gateway Outside Subnet" in title and snapshot:
            for dev_id, dev_data in snapshot.items():
                if dev_id in str(f.get("detail", "")):
                    # Try picking first route in routes
                    routes = dev_data.get("routes", {})
                    if routes:
                        first_net = next(iter(routes.keys()))
                        suggestion["possible_gateway"] = f"An IP in {first_net}"

        optimizations.append(suggestion)

    # Sort by severity
    severity_order = {"high": 1, "medium": 2, "low": 3}
    optimizations.sort(key=lambda s: severity_order.get(s["priority"], 4))

    return optimizations


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python optimizer.py <findings.json> [snapshot.json]")
    else:
        findings_path = sys.argv[1]
        snapshot_path = sys.argv[2] if len(sys.argv) > 2 else None
        with open(findings_path, "r") as f:
            findings = json.load(f)
        opts = optimize_network(findings, snapshot_path)
        print(json.dumps(opts, indent=2))
