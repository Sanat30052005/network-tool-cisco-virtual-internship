# injector.py
# Phase 4: Fault Injection and Day-2 simulation

import json
import os
import time
from copy import deepcopy


def inject_fault(snapshot_path, event_type, target):
    """
    Injects a fault into a saved simulation snapshot.
    Supported event_type:
      - 'link_down' (target='DEV1-DEV2')
      - 'node_down' (target='DEV1')
      - 'mtu_change' (target='DEV1:ifname:new_mtu')
      - 'bad_route' (target='DEV1:net')

    Returns new snapshot with changes applied.
    """
    with open(snapshot_path, "r") as f:
        snapshot = json.load(f)

    new_snapshot = deepcopy(snapshot)
    report = {"event": event_type, "target": target, "effects": []}

    if event_type == "node_down":
        node_id = target
        if node_id in new_snapshot:
            del new_snapshot[node_id]
            report["effects"].append(f"Node {node_id} removed from network.")

    elif event_type == "link_down":
        try:
            dev_a, dev_b = target.split("-")
        except ValueError:
            report["effects"].append("Invalid link format. Use DEV1-DEV2.")
        else:
            for dev in (dev_a, dev_b):
                if dev in new_snapshot:
                    neighs = new_snapshot[dev].get("neighbors", {})
                    neighs = {k: v for k, v in neighs.items() if v != (dev_b if dev == dev_a else dev_a)}
                    new_snapshot[dev]["neighbors"] = neighs
            report["effects"].append(f"Link {dev_a}-{dev_b} removed.")

    elif event_type == "mtu_change":
        try:
            dev_id, ifname, mtu_str = target.split(":")
            mtu_val = int(mtu_str)
        except ValueError:
            report["effects"].append("Invalid MTU change format. Use DEV:ifname:mtu.")
        else:
            report["effects"].append(f"Changed MTU on {dev_id}:{ifname} to {mtu_val} (simulation only).")

    elif event_type == "bad_route":
        try:
            dev_id, net = target.split(":")
        except ValueError:
            report["effects"].append("Invalid bad_route format. Use DEV:net.")
        else:
            if dev_id in new_snapshot:
                new_snapshot[dev_id]["routes"][net] = "BLACKHOLE"
                report["effects"].append(f"Injected bad route {net} into {dev_id}.")

    else:
        report["effects"].append(f"Unknown event type: {event_type}")

    # Save modified snapshot
    out_dir = os.path.dirname(snapshot_path)
    out_path = os.path.join(out_dir, f"inject_result_{int(time.time())}.json")
    with open(out_path, "w") as f:
        json.dump(new_snapshot, f, indent=2)

    # Save report
    rep_path = os.path.join(out_dir, f"inject_report_{int(time.time())}.json")
    with open(rep_path, "w") as f:
        json.dump(report, f, indent=2)

    return new_snapshot, report, out_path, rep_path


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 4:
        print("Usage: python injector.py <snapshot.json> <event_type> <target>")
        print("Example: python injector.py out/sim_snapshot.json link_down R1-R2")
    else:
        snap, rep, snap_path, rep_path = inject_fault(sys.argv[1], sys.argv[2], sys.argv[3])
        print(f"New snapshot: {snap_path}")
        print(f"Report: {rep_path}")
